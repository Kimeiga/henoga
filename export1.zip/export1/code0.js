gdjs.PlaygroundCode = {};
gdjs.PlaygroundCode.GDP1_95HitboxObjects1= [];
gdjs.PlaygroundCode.GDP1_95HitboxObjects2= [];
gdjs.PlaygroundCode.GDP1_95HitboxObjects3= [];
gdjs.PlaygroundCode.GDP1_95HitboxObjects4= [];
gdjs.PlaygroundCode.GDBlock_95SpriteObjects1= [];
gdjs.PlaygroundCode.GDBlock_95SpriteObjects2= [];
gdjs.PlaygroundCode.GDBlock_95SpriteObjects3= [];
gdjs.PlaygroundCode.GDBlock_95SpriteObjects4= [];
gdjs.PlaygroundCode.GDBlock_95TileObjects1= [];
gdjs.PlaygroundCode.GDBlock_95TileObjects2= [];
gdjs.PlaygroundCode.GDBlock_95TileObjects3= [];
gdjs.PlaygroundCode.GDBlock_95TileObjects4= [];
gdjs.PlaygroundCode.GDBlock_95ExtraObjects1= [];
gdjs.PlaygroundCode.GDBlock_95ExtraObjects2= [];
gdjs.PlaygroundCode.GDBlock_95ExtraObjects3= [];
gdjs.PlaygroundCode.GDBlock_95ExtraObjects4= [];
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects1= [];
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects2= [];
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects3= [];
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects4= [];
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects1= [];
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects2= [];
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects3= [];
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects4= [];
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects1= [];
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects2= [];
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects3= [];
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects4= [];
gdjs.PlaygroundCode.GDp1_95hp_95textObjects1= [];
gdjs.PlaygroundCode.GDp1_95hp_95textObjects2= [];
gdjs.PlaygroundCode.GDp1_95hp_95textObjects3= [];
gdjs.PlaygroundCode.GDp1_95hp_95textObjects4= [];
gdjs.PlaygroundCode.GDp1_95gun_95textObjects1= [];
gdjs.PlaygroundCode.GDp1_95gun_95textObjects2= [];
gdjs.PlaygroundCode.GDp1_95gun_95textObjects3= [];
gdjs.PlaygroundCode.GDp1_95gun_95textObjects4= [];
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects1= [];
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects2= [];
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects3= [];
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects4= [];
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects1= [];
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects2= [];
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects3= [];
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects4= [];
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects1= [];
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects2= [];
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects3= [];
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects4= [];
gdjs.PlaygroundCode.GDp2_95hp_95textObjects1= [];
gdjs.PlaygroundCode.GDp2_95hp_95textObjects2= [];
gdjs.PlaygroundCode.GDp2_95hp_95textObjects3= [];
gdjs.PlaygroundCode.GDp2_95hp_95textObjects4= [];
gdjs.PlaygroundCode.GDp2_95gun_95textObjects1= [];
gdjs.PlaygroundCode.GDp2_95gun_95textObjects2= [];
gdjs.PlaygroundCode.GDp2_95gun_95textObjects3= [];
gdjs.PlaygroundCode.GDp2_95gun_95textObjects4= [];
gdjs.PlaygroundCode.GDwin_95textObjects1= [];
gdjs.PlaygroundCode.GDwin_95textObjects2= [];
gdjs.PlaygroundCode.GDwin_95textObjects3= [];
gdjs.PlaygroundCode.GDwin_95textObjects4= [];
gdjs.PlaygroundCode.GDp2Objects1= [];
gdjs.PlaygroundCode.GDp2Objects2= [];
gdjs.PlaygroundCode.GDp2Objects3= [];
gdjs.PlaygroundCode.GDp2Objects4= [];
gdjs.PlaygroundCode.GDp2_95bulletObjects1= [];
gdjs.PlaygroundCode.GDp2_95bulletObjects2= [];
gdjs.PlaygroundCode.GDp2_95bulletObjects3= [];
gdjs.PlaygroundCode.GDp2_95bulletObjects4= [];
gdjs.PlaygroundCode.GDp2_95gunObjects1= [];
gdjs.PlaygroundCode.GDp2_95gunObjects2= [];
gdjs.PlaygroundCode.GDp2_95gunObjects3= [];
gdjs.PlaygroundCode.GDp2_95gunObjects4= [];
gdjs.PlaygroundCode.GDp2_95aimObjects1= [];
gdjs.PlaygroundCode.GDp2_95aimObjects2= [];
gdjs.PlaygroundCode.GDp2_95aimObjects3= [];
gdjs.PlaygroundCode.GDp2_95aimObjects4= [];
gdjs.PlaygroundCode.GDp1Objects1= [];
gdjs.PlaygroundCode.GDp1Objects2= [];
gdjs.PlaygroundCode.GDp1Objects3= [];
gdjs.PlaygroundCode.GDp1Objects4= [];
gdjs.PlaygroundCode.GDp1_95bulletObjects1= [];
gdjs.PlaygroundCode.GDp1_95bulletObjects2= [];
gdjs.PlaygroundCode.GDp1_95bulletObjects3= [];
gdjs.PlaygroundCode.GDp1_95bulletObjects4= [];
gdjs.PlaygroundCode.GDp1_95gunObjects1= [];
gdjs.PlaygroundCode.GDp1_95gunObjects2= [];
gdjs.PlaygroundCode.GDp1_95gunObjects3= [];
gdjs.PlaygroundCode.GDp1_95gunObjects4= [];
gdjs.PlaygroundCode.GDp1_95aimObjects1= [];
gdjs.PlaygroundCode.GDp1_95aimObjects2= [];
gdjs.PlaygroundCode.GDp1_95aimObjects3= [];
gdjs.PlaygroundCode.GDp1_95aimObjects4= [];
gdjs.PlaygroundCode.GDpistolObjects1= [];
gdjs.PlaygroundCode.GDpistolObjects2= [];
gdjs.PlaygroundCode.GDpistolObjects3= [];
gdjs.PlaygroundCode.GDpistolObjects4= [];
gdjs.PlaygroundCode.GDJumpthruObjects1= [];
gdjs.PlaygroundCode.GDJumpthruObjects2= [];
gdjs.PlaygroundCode.GDJumpthruObjects3= [];
gdjs.PlaygroundCode.GDJumpthruObjects4= [];
gdjs.PlaygroundCode.GDWallObjects1= [];
gdjs.PlaygroundCode.GDWallObjects2= [];
gdjs.PlaygroundCode.GDWallObjects3= [];
gdjs.PlaygroundCode.GDWallObjects4= [];
gdjs.PlaygroundCode.GDLadderObjects1= [];
gdjs.PlaygroundCode.GDLadderObjects2= [];
gdjs.PlaygroundCode.GDLadderObjects3= [];
gdjs.PlaygroundCode.GDLadderObjects4= [];

gdjs.PlaygroundCode.conditionTrue_0 = {val:false};
gdjs.PlaygroundCode.condition0IsTrue_0 = {val:false};
gdjs.PlaygroundCode.condition1IsTrue_0 = {val:false};
gdjs.PlaygroundCode.condition2IsTrue_0 = {val:false};
gdjs.PlaygroundCode.condition3IsTrue_0 = {val:false};
gdjs.PlaygroundCode.condition4IsTrue_0 = {val:false};


gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.eventsList0x7920fc = function(runtimeScene) {

{

gdjs.PlaygroundCode.GDp2Objects2.createFrom(gdjs.PlaygroundCode.GDp2Objects1);


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects2.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp2Objects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects2[k] = gdjs.PlaygroundCode.GDp2Objects2[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects2.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects2 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "k"));
}}
if (gdjs.PlaygroundCode.condition1IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects2.createFrom(gdjs.PlaygroundCode.GDp2Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects2[i].setAnimation(5);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
gdjs.PlaygroundCode.condition2IsTrue_0.val = false;
gdjs.PlaygroundCode.condition3IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Down");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "k"));
}if ( gdjs.PlaygroundCode.condition1IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition2IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left"));
}if ( gdjs.PlaygroundCode.condition2IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition3IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right"));
}}
}
}
if (gdjs.PlaygroundCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setY(gdjs.PlaygroundCode.GDp2Objects1[i].getY() - (11));
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x7920fc
gdjs.PlaygroundCode.eventsList0x73e654 = function(runtimeScene) {

{

gdjs.PlaygroundCode.GDp1Objects2.createFrom(gdjs.PlaygroundCode.GDp1Objects1);


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects2.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp1Objects2[i].getBehavior("PlatformerObject").isMoving()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects2[k] = gdjs.PlaygroundCode.GDp1Objects2[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects2.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects2 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects2[i].setAnimation(0);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "x"));
}}
if (gdjs.PlaygroundCode.condition1IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects2.createFrom(gdjs.PlaygroundCode.GDp1Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects2[i].getBehavior("PlatformerObject").simulateDownKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects2[i].setAnimation(5);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
gdjs.PlaygroundCode.condition2IsTrue_0.val = false;
gdjs.PlaygroundCode.condition3IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "s");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "a"));
}if ( gdjs.PlaygroundCode.condition1IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition2IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "d"));
}if ( gdjs.PlaygroundCode.condition2IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition3IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "x"));
}}
}
}
if (gdjs.PlaygroundCode.condition3IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setY(gdjs.PlaygroundCode.GDp1Objects1[i].getY() - (11));
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x73e654
gdjs.PlaygroundCode.eventsList0x786fd4 = function(runtimeScene) {

{

gdjs.PlaygroundCode.GDp2Objects2.createFrom(gdjs.PlaygroundCode.GDp2Objects1);


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects2.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp2Objects2[i].getBehavior("PlatformerObject").isGrabbingPlatform()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects2[k] = gdjs.PlaygroundCode.GDp2Objects2[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects2.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects2 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects2[i].flipX(false);
}
}}

}


{



}


}; //End of gdjs.PlaygroundCode.eventsList0x786fd4
gdjs.PlaygroundCode.eventsList0x73c54c = function(runtimeScene) {

{



}


{

/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isGrabbingPlatform()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].flipX(false);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x73c54c
gdjs.PlaygroundCode.eventsList0x76140c = function(runtimeScene) {

{



}


{

/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").isGrabbingPlatform()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].flipX(true);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x76140c
gdjs.PlaygroundCode.eventsList0x73cf6c = function(runtimeScene) {

{



}


{

/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( !(gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isGrabbingPlatform()) ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].flipX(true);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x73cf6c
gdjs.PlaygroundCode.eventsList0x79758c = function(runtimeScene) {

{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects3.createFrom(gdjs.PlaygroundCode.GDp2Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects3.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects3[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects3[i].getVariables().getFromIndex(2)).sub(2);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects2.createFrom(gdjs.PlaygroundCode.GDp2Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects2[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects2[i].getVariables().getFromIndex(2)).add(2);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x79758c
gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2_9595bulletObjects1Objects = Hashtable.newFrom({"p2_bullet": gdjs.PlaygroundCode.GDp2_95bulletObjects1});gdjs.PlaygroundCode.eventsList0x797aec = function(runtimeScene) {

{

/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(5)) == 0 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2_95gunObjects1.createFrom(runtimeScene.getObjects("p2_gun"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95gunObjects1[i].setAnimation(0);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x797aec
gdjs.PlaygroundCode.eventsList0x75bdcc = function(runtimeScene) {

{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "k");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2_95aimObjects2.createFrom(runtimeScene.getObjects("p2_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95aimObjects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95aimObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x79758c(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "k");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
gdjs.PlaygroundCode.GDp2_95bulletObjects1.createFrom(runtimeScene.getObjects("p2_bullet"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("FireBullet").Fire((gdjs.PlaygroundCode.GDp2Objects1[i].getPointX("Center")), (gdjs.PlaygroundCode.GDp2Objects1[i].getPointY("Center")), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2_9595bulletObjects1Objects, (gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(0))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(2))) * (gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(3)))), 300, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95bulletObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95bulletObjects1[i].setZOrder(300);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(5)).sub(1);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x797aec(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.PlaygroundCode.eventsList0x75bdcc
gdjs.PlaygroundCode.eventsList0x73d8a4 = function(runtimeScene) {

{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects3.createFrom(gdjs.PlaygroundCode.GDp1Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects3.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects3[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects3[i].getVariables().getFromIndex(3)).sub(2);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects2.createFrom(gdjs.PlaygroundCode.GDp1Objects1);

{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects2[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects2[i].getVariables().getFromIndex(3)).add(2);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x73d8a4
gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1_9595bulletObjects1Objects = Hashtable.newFrom({"p1_bullet": gdjs.PlaygroundCode.GDp1_95bulletObjects1});gdjs.PlaygroundCode.eventsList0x73de14 = function(runtimeScene) {

{

/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(5)) == 0 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1_95gunObjects1.createFrom(runtimeScene.getObjects("p1_gun"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95gunObjects1[i].setAnimation(0);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x73de14
gdjs.PlaygroundCode.eventsList0x726ddc = function(runtimeScene) {

{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "x");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1_95aimObjects2.createFrom(runtimeScene.getObjects("p1_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95aimObjects2.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95aimObjects2[i].hide(false);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x73d8a4(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "x");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
gdjs.PlaygroundCode.GDp1_95bulletObjects1.createFrom(runtimeScene.getObjects("p1_bullet"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("FireBullet").Fire((gdjs.PlaygroundCode.GDp1Objects1[i].getPointX("Center")), (gdjs.PlaygroundCode.GDp1Objects1[i].getPointY("Center")), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1_9595bulletObjects1Objects, (gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(1))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(3))) * (gdjs.RuntimeObject.getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(0)))), 300, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95bulletObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95bulletObjects1[i].setZOrder(300);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(5)).sub(1);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x73de14(runtimeScene);} //End of subevents
}

}


}; //End of gdjs.PlaygroundCode.eventsList0x726ddc
gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2Objects1Objects = Hashtable.newFrom({"p2": gdjs.PlaygroundCode.GDp2Objects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1Objects1Objects = Hashtable.newFrom({"p1": gdjs.PlaygroundCode.GDp1Objects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2Objects1Objects = Hashtable.newFrom({"p2": gdjs.PlaygroundCode.GDp2Objects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1_9595bulletObjects1Objects = Hashtable.newFrom({"p1_bullet": gdjs.PlaygroundCode.GDp1_95bulletObjects1});gdjs.PlaygroundCode.eventsList0x785334 = function(runtimeScene) {

{

/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(4)) < 1 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
gdjs.PlaygroundCode.GDwin_95textObjects1.createFrom(runtimeScene.getObjects("win_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDwin_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDwin_95textObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDwin_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDwin_95textObjects1[i].setString("P1 Wins!");
}
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "win_restart_delay");
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(6);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x785334
gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1Objects1Objects = Hashtable.newFrom({"p1": gdjs.PlaygroundCode.GDp1Objects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2_9595bulletObjects1Objects = Hashtable.newFrom({"p2_bullet": gdjs.PlaygroundCode.GDp2_95bulletObjects1});gdjs.PlaygroundCode.eventsList0x74c9fc = function(runtimeScene) {

{

/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(4)) < 1 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
gdjs.PlaygroundCode.GDwin_95textObjects1.createFrom(runtimeScene.getObjects("win_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDwin_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDwin_95textObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDwin_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDwin_95textObjects1[i].setString("P2 Wins!");
}
}{gdjs.evtTools.runtimeScene.unpauseTimer(runtimeScene, "win_restart_delay");
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(6);
}
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0x74c9fc
gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects = Hashtable.newFrom({"pistol": gdjs.PlaygroundCode.GDpistolObjects1});gdjs.PlaygroundCode.eventsList0xb5aa0 = function(runtimeScene) {

{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDpistolObjects1.length = 0;

{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "win_restart_delay");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "win_restart_delay");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, gdjs.randomInRange(256, 512), gdjs.randomInRange(0, 240), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, gdjs.randomInRange(0, 256), gdjs.randomInRange(0, 240), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gun_spawn_delay");
}}

}


{


{
}

}


{



}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "k"));
}}
if (gdjs.PlaygroundCode.condition1IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
gdjs.PlaygroundCode.condition1IsTrue_0.val = !(gdjs.evtTools.input.isKeyPressed(runtimeScene, "x"));
}}
if (gdjs.PlaygroundCode.condition1IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").simulateLadderKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").simulateUpKey();
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlaygroundCode.eventsList0x7920fc(runtimeScene);} //End of subevents
}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.PlaygroundCode.eventsList0x73e654(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(0)).setNumber(0);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(3)).setNumber(1);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x786fd4(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").simulateRightKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(1)).setNumber(0);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x73c54c(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(3)).setNumber(-(1));
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x76140c(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").simulateLeftKey();
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(0)).setNumber(-(1));
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x73cf6c(runtimeScene);} //End of subevents
}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(2);
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(2);
}
}}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(3);
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").isFalling() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(3);
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(4);
}
}}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getBehavior("PlatformerObject").isGrabbingPlatform() ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(4);
}
}}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(4)) < 1 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].setAnimation(6);
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(4)) < 1 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].setAnimation(6);
}
}}

}


{



}


{


{
gdjs.PlaygroundCode.GDp2_95aimObjects1.createFrom(runtimeScene.getObjects("p2_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95aimObjects1[i].hide();
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1_95aimObjects1.createFrom(runtimeScene.getObjects("p1_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95aimObjects1[i].hide();
}
}}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
gdjs.PlaygroundCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableString(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(1)) != "gunless" ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(5)) > 0 ) {
        gdjs.PlaygroundCode.condition1IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}if ( gdjs.PlaygroundCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp2Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp2Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(4)) > 0 ) {
        gdjs.PlaygroundCode.condition2IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp2Objects1[k] = gdjs.PlaygroundCode.GDp2Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp2Objects1.length = k;}}
}
if (gdjs.PlaygroundCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.PlaygroundCode.eventsList0x75bdcc(runtimeScene);} //End of subevents
}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
gdjs.PlaygroundCode.condition1IsTrue_0.val = false;
gdjs.PlaygroundCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(5)) > 0 ) {
        gdjs.PlaygroundCode.condition0IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if ( gdjs.PlaygroundCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableNumber(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(4)) > 0 ) {
        gdjs.PlaygroundCode.condition1IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}if ( gdjs.PlaygroundCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.PlaygroundCode.GDp1Objects1.length;i<l;++i) {
    if ( gdjs.PlaygroundCode.GDp1Objects1[i].getVariableString(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(2)) != "gunless" ) {
        gdjs.PlaygroundCode.condition2IsTrue_0.val = true;
        gdjs.PlaygroundCode.GDp1Objects1[k] = gdjs.PlaygroundCode.GDp1Objects1[i];
        ++k;
    }
}
gdjs.PlaygroundCode.GDp1Objects1.length = k;}}
}
if (gdjs.PlaygroundCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.PlaygroundCode.eventsList0x726ddc(runtimeScene);} //End of subevents
}

}


{

gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDpistolObjects1.createFrom(runtimeScene.getObjects("pistol"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2Objects1Objects, gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, false, runtimeScene, false);
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
gdjs.PlaygroundCode.GDp2_95gunObjects1.createFrom(runtimeScene.getObjects("p2_gun"));
/* Reuse gdjs.PlaygroundCode.GDpistolObjects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(1)).setString("pistol");
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95gunObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(5)).setNumber(30);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDpistolObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDpistolObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDpistolObjects1.createFrom(runtimeScene.getObjects("pistol"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1Objects1Objects, gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, false, runtimeScene, false);
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
gdjs.PlaygroundCode.GDp1_95gunObjects1.createFrom(runtimeScene.getObjects("p1_gun"));
/* Reuse gdjs.PlaygroundCode.GDpistolObjects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(2)).setString("pistol");
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95gunObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(5)).setNumber(30);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDpistolObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDpistolObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


{


{
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDp2_95gunObjects1.createFrom(runtimeScene.getObjects("p2_gun"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95gunObjects1[i].rotateTowardAngle((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(0))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(2))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(3)))), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95gunObjects1[i].putAroundObject((gdjs.PlaygroundCode.GDp2Objects1.length !== 0 ? gdjs.PlaygroundCode.GDp2Objects1[0] : null), 0, 0);
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp1_95gunObjects1.createFrom(runtimeScene.getObjects("p1_gun"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95gunObjects1[i].rotateTowardAngle((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(1))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(3))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(0)))), 0, runtimeScene);
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95gunObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95gunObjects1[i].putAroundObject((gdjs.PlaygroundCode.GDp1Objects1.length !== 0 ? gdjs.PlaygroundCode.GDp1Objects1[0] : null), 0, 0);
}
}}

}


{



}


{


{
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDp2_95aimObjects1.createFrom(runtimeScene.getObjects("p2_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95aimObjects1[i].putAroundObject((gdjs.PlaygroundCode.GDp2Objects1.length !== 0 ? gdjs.PlaygroundCode.GDp2Objects1[0] : null), 0, (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(0))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(2))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(3)))));
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95aimObjects1[i].rotateTowardAngle((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(0))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(2))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(3)))), 0, runtimeScene);
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp1_95aimObjects1.createFrom(runtimeScene.getObjects("p1_aim"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95aimObjects1[i].putAroundObject((gdjs.PlaygroundCode.GDp1Objects1.length !== 0 ? gdjs.PlaygroundCode.GDp1Objects1[0] : null), 0, (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(1))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(3))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(0)))));
}
}{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95aimObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95aimObjects1[i].rotateTowardAngle((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(1))) * 180 + ((gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(3))) * (gdjs.RuntimeObject.getVariableNumber(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(0)))), 0, runtimeScene);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "l");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "c");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(3)).setNumber(0);
}
}}

}


{



}


{


{
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDp2_95gun_95textObjects1.createFrom(runtimeScene.getObjects("p2_gun_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95gun_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95gun_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(1))));
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp1_95gun_95textObjects1.createFrom(runtimeScene.getObjects("p1_gun_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95gun_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95gun_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(2))));
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp1_95hp_95textObjects1.createFrom(runtimeScene.getObjects("p1_hp_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95hp_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95hp_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(4))));
}
}}

}


{


{
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDp2_95hp_95textObjects1.createFrom(runtimeScene.getObjects("p2_hp_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95hp_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95hp_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(4))));
}
}}

}


{


{
gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects1.createFrom(runtimeScene.getObjects("p1_ammo_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1_95ammo_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1_95ammo_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp1Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp1Objects1[0].getVariables()).getFromIndex(5))));
}
}}

}


{


{
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects1.createFrom(runtimeScene.getObjects("p2_ammo_text"));
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2_95ammo_95textObjects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2_95ammo_95textObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.PlaygroundCode.GDp2Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.PlaygroundCode.GDp2Objects1[0].getVariables()).getFromIndex(5))));
}
}}

}


{



}


{

gdjs.PlaygroundCode.GDp1_95bulletObjects1.createFrom(runtimeScene.getObjects("p1_bullet"));
gdjs.PlaygroundCode.GDp2Objects1.createFrom(runtimeScene.getObjects("p2"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2Objects1Objects, gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1_9595bulletObjects1Objects, false, runtimeScene, false);
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp2Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp2Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp2Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp2Objects1[i].getVariables().getFromIndex(4)).sub(10);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x785334(runtimeScene);} //End of subevents
}

}


{

gdjs.PlaygroundCode.GDp1Objects1.createFrom(runtimeScene.getObjects("p1"));
gdjs.PlaygroundCode.GDp2_95bulletObjects1.createFrom(runtimeScene.getObjects("p2_bullet"));

gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp1Objects1Objects, gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDp2_9595bulletObjects1Objects, false, runtimeScene, false);
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
/* Reuse gdjs.PlaygroundCode.GDp1Objects1 */
{for(var i = 0, len = gdjs.PlaygroundCode.GDp1Objects1.length ;i < len;++i) {
    gdjs.PlaygroundCode.GDp1Objects1[i].returnVariable(gdjs.PlaygroundCode.GDp1Objects1[i].getVariables().getFromIndex(4)).sub(10);
}
}
{ //Subevents
gdjs.PlaygroundCode.eventsList0x74c9fc(runtimeScene);} //End of subevents
}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 5, "win_restart_delay");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Playground", true);
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "win_restart_delay");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "win_restart_delay");
}}

}


{


gdjs.PlaygroundCode.condition0IsTrue_0.val = false;
{
gdjs.PlaygroundCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 10, "gun_spawn_delay");
}if (gdjs.PlaygroundCode.condition0IsTrue_0.val) {
gdjs.PlaygroundCode.GDpistolObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, gdjs.randomInRange(256, 512), gdjs.randomInRange(0, 240), "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.PlaygroundCode.mapOfGDgdjs_46PlaygroundCode_46GDpistolObjects1Objects, gdjs.randomInRange(0, 256), gdjs.randomInRange(0, 240), "");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "gun_spawn_delay");
}}

}


}; //End of gdjs.PlaygroundCode.eventsList0xb5aa0


gdjs.PlaygroundCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.PlaygroundCode.GDP1_95HitboxObjects1.length = 0;
gdjs.PlaygroundCode.GDP1_95HitboxObjects2.length = 0;
gdjs.PlaygroundCode.GDP1_95HitboxObjects3.length = 0;
gdjs.PlaygroundCode.GDP1_95HitboxObjects4.length = 0;
gdjs.PlaygroundCode.GDBlock_95SpriteObjects1.length = 0;
gdjs.PlaygroundCode.GDBlock_95SpriteObjects2.length = 0;
gdjs.PlaygroundCode.GDBlock_95SpriteObjects3.length = 0;
gdjs.PlaygroundCode.GDBlock_95SpriteObjects4.length = 0;
gdjs.PlaygroundCode.GDBlock_95TileObjects1.length = 0;
gdjs.PlaygroundCode.GDBlock_95TileObjects2.length = 0;
gdjs.PlaygroundCode.GDBlock_95TileObjects3.length = 0;
gdjs.PlaygroundCode.GDBlock_95TileObjects4.length = 0;
gdjs.PlaygroundCode.GDBlock_95ExtraObjects1.length = 0;
gdjs.PlaygroundCode.GDBlock_95ExtraObjects2.length = 0;
gdjs.PlaygroundCode.GDBlock_95ExtraObjects3.length = 0;
gdjs.PlaygroundCode.GDBlock_95ExtraObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95labelObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95labelObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95ammo_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95hp_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95gun_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95gun_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95gun_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95gun_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95ammo_95labelObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95labelObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95hp_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95gun_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95gun_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95gun_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95gun_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDwin_95textObjects1.length = 0;
gdjs.PlaygroundCode.GDwin_95textObjects2.length = 0;
gdjs.PlaygroundCode.GDwin_95textObjects3.length = 0;
gdjs.PlaygroundCode.GDwin_95textObjects4.length = 0;
gdjs.PlaygroundCode.GDp2Objects1.length = 0;
gdjs.PlaygroundCode.GDp2Objects2.length = 0;
gdjs.PlaygroundCode.GDp2Objects3.length = 0;
gdjs.PlaygroundCode.GDp2Objects4.length = 0;
gdjs.PlaygroundCode.GDp2_95bulletObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95bulletObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95bulletObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95bulletObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95gunObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95gunObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95gunObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95gunObjects4.length = 0;
gdjs.PlaygroundCode.GDp2_95aimObjects1.length = 0;
gdjs.PlaygroundCode.GDp2_95aimObjects2.length = 0;
gdjs.PlaygroundCode.GDp2_95aimObjects3.length = 0;
gdjs.PlaygroundCode.GDp2_95aimObjects4.length = 0;
gdjs.PlaygroundCode.GDp1Objects1.length = 0;
gdjs.PlaygroundCode.GDp1Objects2.length = 0;
gdjs.PlaygroundCode.GDp1Objects3.length = 0;
gdjs.PlaygroundCode.GDp1Objects4.length = 0;
gdjs.PlaygroundCode.GDp1_95bulletObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95bulletObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95bulletObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95bulletObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95gunObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95gunObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95gunObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95gunObjects4.length = 0;
gdjs.PlaygroundCode.GDp1_95aimObjects1.length = 0;
gdjs.PlaygroundCode.GDp1_95aimObjects2.length = 0;
gdjs.PlaygroundCode.GDp1_95aimObjects3.length = 0;
gdjs.PlaygroundCode.GDp1_95aimObjects4.length = 0;
gdjs.PlaygroundCode.GDpistolObjects1.length = 0;
gdjs.PlaygroundCode.GDpistolObjects2.length = 0;
gdjs.PlaygroundCode.GDpistolObjects3.length = 0;
gdjs.PlaygroundCode.GDpistolObjects4.length = 0;
gdjs.PlaygroundCode.GDJumpthruObjects1.length = 0;
gdjs.PlaygroundCode.GDJumpthruObjects2.length = 0;
gdjs.PlaygroundCode.GDJumpthruObjects3.length = 0;
gdjs.PlaygroundCode.GDJumpthruObjects4.length = 0;
gdjs.PlaygroundCode.GDWallObjects1.length = 0;
gdjs.PlaygroundCode.GDWallObjects2.length = 0;
gdjs.PlaygroundCode.GDWallObjects3.length = 0;
gdjs.PlaygroundCode.GDWallObjects4.length = 0;
gdjs.PlaygroundCode.GDLadderObjects1.length = 0;
gdjs.PlaygroundCode.GDLadderObjects2.length = 0;
gdjs.PlaygroundCode.GDLadderObjects3.length = 0;
gdjs.PlaygroundCode.GDLadderObjects4.length = 0;

gdjs.PlaygroundCode.eventsList0xb5aa0(runtimeScene);
return;

}
gdjs['PlaygroundCode'] = gdjs.PlaygroundCode;
